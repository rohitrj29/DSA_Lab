#include "node.h"
#include<stdio.h>

extern int * Arr[N];
extern int Num_Elements[N];

void InsertionSort_GM(int arr[], int n) 
{

 
} 

void InsertionSort_Arr()
{


}


