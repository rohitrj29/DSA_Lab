#include<stdio.h>
#include"node.h"

extern int * Arr[N];
extern int Num_Elements[N];

void Merge_GM(int *Ls1, int sz1, int * Ls2, int sz2, int* Ls)
{
  
}

void Merge_Arr()
{
      
}


